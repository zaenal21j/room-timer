const {app,BrowserWindow,powerSaveBlocker}=require('electron');
const path=require('node:path');
let blocker;
function createWindow(){
 const win=new BrowserWindow({width:1120,height:850,minWidth:380,minHeight:600,backgroundColor:'#111612',autoHideMenuBar:true,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,backgroundThrottling:false}});
 win.loadFile(path.join(__dirname,'web','index.html'));
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-navigate',event=>event.preventDefault());
}
app.whenReady().then(()=>{blocker=powerSaveBlocker.start('prevent-display-sleep');createWindow();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
app.on('will-quit',()=>{if(blocker!==undefined&&powerSaveBlocker.isStarted(blocker))powerSaveBlocker.stop(blocker)});
