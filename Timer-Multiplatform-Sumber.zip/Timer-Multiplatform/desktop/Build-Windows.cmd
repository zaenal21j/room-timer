@echo off
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
 echo Install Node.js LTS dari https://nodejs.org terlebih dahulu.
 pause
 exit /b 1
)
call npm install
if errorlevel 1 goto gagal
call npm run build:windows
if errorlevel 1 goto gagal
explorer release
pause
exit /b 0
:gagal
echo Build gagal. Periksa pesan di atas.
pause
exit /b 1
