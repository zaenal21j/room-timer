#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v npm >/dev/null; then
 echo 'Install Node.js LTS dari https://nodejs.org terlebih dahulu.'
 read -r -p 'Tekan Enter untuk menutup...'
 exit 1
fi
npm install
npm run build:mac
open release
